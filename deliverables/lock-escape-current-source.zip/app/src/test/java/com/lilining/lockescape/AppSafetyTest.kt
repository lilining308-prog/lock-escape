/*
 * Copyright (C) 2026 liyan
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

package com.lilining.lockescape

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AppSafetyTest {
    @Test
    fun platformPhoneAndInputPackagesCannotBeTrackedAsSuspects() {
        assertFalse(AppSafety.shouldTrackTopPackage("com.android.settings", emptySet()))
        assertFalse(AppSafety.shouldTrackTopPackage("android", emptySet()))
        assertFalse(AppSafety.shouldTrackTopPackage("com.google.android.apps.nexuslauncher", emptySet()))
        assertFalse(AppSafety.shouldTrackTopPackage("not a package", emptySet()))
    }

    @Test
    fun coreInputMethodAndShizukuRemainProtectedEvenIfMisidentified() {
        assertFalse(ShellExecutor.forceStopForTest("com.google.android.inputmethod.latin").first)
        assertFalse(ShellExecutor.disableForTest("moe.shizuku.privileged.api").first)
        assertFalse(ShellExecutor.uninstallForTest("com.android.inputmethod.latin").first)
    }
    @Test
    fun criticalSystemPackagesAreProtected() {
        assertTrue(AppSafety.isProtectedPackage("com.android.systemui"))
        assertTrue(AppSafety.isProtectedPackage("com.android.settings"))
        assertTrue(AppSafety.isProtectedPackage("com.android.launcher3"))
    }

    @Test
    fun ordinaryPreinstalledPackagesAreNotBlockedByPackageFlagAlone() {
        assertFalse(AppSafety.isProtectedPackage("com.android.chrome"))
        assertFalse(AppSafety.isProtectedPackage("com.google.android.youtube"))
    }

    @Test
    fun launchersAreWhitelistedByDefault() {
        assertTrue(AppSafety.isWhitelistedPackage("com.android.launcher3", emptySet()))
        assertTrue(AppSafety.isWhitelistedPackage("com.google.android.apps.nexuslauncher", emptySet()))
        assertTrue(AppSafety.isWhitelistedPackage("com.miui.home", emptySet()))
    }

    @Test
    fun userWhitelistPackagesAreWhitelisted() {
        val userWhitelist = setOf("com.example.safe")

        assertTrue(AppSafety.isWhitelistedPackage("com.example.safe", userWhitelist))
        assertFalse(AppSafety.isWhitelistedPackage("com.example.risk", userWhitelist))
    }

    @Test
    fun whitelistedPackagesAreNotTrackedAsTopRiskPackage() {
        assertFalse(AppSafety.shouldTrackTopPackage("com.android.launcher3", emptySet()))
        assertFalse(AppSafety.shouldTrackTopPackage("com.example.safe", setOf("com.example.safe")))
        assertTrue(AppSafety.shouldTrackTopPackage("com.example.risk", setOf("com.example.safe")))
    }

    @Test
    fun activeKeyboardNeverReplacesTrackedTarget() {
        assertFalse(
            AppSafety.shouldTrackTopPackage(
                "com.google.android.inputmethod.latin",
                emptySet(),
                inputMethodPackage = "com.google.android.inputmethod.latin"
            )
        )
        assertTrue(
            AppSafety.shouldTrackTopPackage(
                "com.example.risk",
                emptySet(),
                inputMethodPackage = "com.google.android.inputmethod.latin"
            )
        )
    }

    @Test
    fun packageNameValidationRejectsInvalidInput() {
        assertTrue(AppSafety.isValidPackageName("com.example.safe"))
        assertTrue(AppSafety.isValidPackageName("a.b_1.c2"))
        assertFalse(AppSafety.isValidPackageName(""))
        assertFalse(AppSafety.isValidPackageName("com example safe"))
        assertFalse(AppSafety.isValidPackageName("com.example."))
        assertFalse(AppSafety.isValidPackageName(".com.example"))
    }

    @Test
    fun normalizeWhitelistTrimsBlanksAndDropsInvalidPackages() {
        val normalized = AppSafety.normalizeUserWhitelist(
            setOf(" com.example.safe ", "", "bad package", "com.example.safe", "com.other.app")
        )

        assertTrue("com.example.safe" in normalized)
        assertTrue("com.other.app" in normalized)
        assertFalse("bad package" in normalized)
        assertFalse("" in normalized)
    }

    @Test
    fun packageNameValidatorDoesNotSilentlyAcceptPaddedNames() {
        assertFalse(AppSafety.isValidPackageName(" com.example.safe "))
        assertFalse(AppSafety.isValidPackageName("com.example.safe\n"))
        assertTrue(AppSafety.normalizeUserWhitelist(setOf(" com.example.safe ")).contains("com.example.safe"))
    }

    @Test
    fun shellMetacharactersAndControlCharactersAreNeverPackageNames() {
        for (pkg in listOf("com.example.app;id", "com.example.app\u0000", "com.example.app\nreboot", "com.example.app`id`")) {
            assertFalse(AppSafety.isValidPackageName(pkg))
            assertFalse(ShellExecutor.forceStopForTest(pkg).first)
        }
    }

    @Test
    fun unicodeLookalikesAndLeadingDigitsAreNotShellPackageNames() {
        assertFalse(AppSafety.isValidPackageName("com.example.安全"))
        assertFalse(AppSafety.isValidPackageName("1com.example.app"))
        assertTrue(AppSafety.isValidPackageName("com.example.app_2"))
    }

    @Test
    fun whitespaceSeparatedUserWhitelistIsNormalizedWithoutAllowingShellWhitespace() {
        val normalized = AppSafety.normalizeUserWhitelist(setOf("\tcom.example.safe\t"))
        assertTrue("com.example.safe" in normalized)
        assertFalse(AppSafety.isValidPackageName("\tcom.example.safe\t"))
    }

    @Test
    fun packageNameWithInternalSpacesIsNeverNormalizedIntoExecutableCommand() {
        assertFalse(AppSafety.isValidPackageName("com.example. app"))
        assertFalse(ShellExecutor.disableForTest("com.example. app").first)
    }

    @Test
    fun caseSensitivePackageNamesAreNotLowercasedByValidation() {
        assertTrue(AppSafety.isValidPackageName("com.Example.Locker"))
        assertTrue(ShellExecutor.forceStopCommandForTest("com.Example.Locker") == "am force-stop com.Example.Locker")
    }

    @Test
    fun packageNameWithoutDotCannotBeUsedForActions() {
        assertFalse(AppSafety.isValidPackageName("singlepackage"))
        assertFalse(ShellExecutor.forceStopForTest("singlepackage").first)
    }
}
