/*
 * Copyright (C) 2026 liyan
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

package com.lilining.lockescape

class VolumeKeyTrigger {
    private var sequenceStartTime = 0L
    private var consecutiveCount = 0
    private var volumeDownPressed = false
    private var volumeUpPressed = false

    fun onVolumeDown(keyCode: Int, now: Long, isRepeat: Boolean = false): Decision {
        if (keyCode != KEY_VOLUME_DOWN && keyCode != KEY_VOLUME_UP) return Decision(false, false, false)
        if (isRepeat || (keyCode == KEY_VOLUME_DOWN && volumeDownPressed) ||
            (keyCode == KEY_VOLUME_UP && volumeUpPressed)) {
            return Decision(scheduleLongPress = false, cancelLongPress = false, triggerEscape = false)
        }

        val scheduleLongPress = keyCode == KEY_VOLUME_DOWN && !volumeDownPressed
        if (keyCode == KEY_VOLUME_DOWN) {
            volumeDownPressed = true
        } else if (keyCode == KEY_VOLUME_UP) {
            volumeUpPressed = true
        }

        if (consecutiveCount == 0 || now < sequenceStartTime || now - sequenceStartTime > TRIGGER_WINDOW_MS) {
            consecutiveCount = 0
            sequenceStartTime = now
        }
        consecutiveCount++

        val triggerEscape = consecutiveCount >= TRIGGER_COUNT
        if (triggerEscape) {
            consecutiveCount = 0
            sequenceStartTime = 0L
        }

        return Decision(
            scheduleLongPress = scheduleLongPress,
            cancelLongPress = false,
            triggerEscape = triggerEscape
        )
    }

    fun onVolumeUp(keyCode: Int): Decision {
        val cancelLongPress = keyCode == KEY_VOLUME_DOWN && volumeDownPressed
        if (keyCode == KEY_VOLUME_DOWN) {
            volumeDownPressed = false
        } else if (keyCode == KEY_VOLUME_UP) {
            volumeUpPressed = false
        }
        return Decision(
            scheduleLongPress = false,
            cancelLongPress = cancelLongPress,
            triggerEscape = false
        )
    }

    fun resetAfterTrigger() {
        consecutiveCount = 0
        sequenceStartTime = 0L
    }

    data class Decision(
        val scheduleLongPress: Boolean,
        val cancelLongPress: Boolean,
        val triggerEscape: Boolean
    )

    companion object {
        const val KEY_VOLUME_UP = 24
        const val KEY_VOLUME_DOWN = 25
        const val TRIGGER_COUNT = 4
        const val TRIGGER_WINDOW_MS = 1500L
        const val LONG_PRESS_MS = 1500L
    }
}
