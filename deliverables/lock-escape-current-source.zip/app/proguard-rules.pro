# Shizuku
-keep class rikka.shizuku.** { *; }
-dontwarn rikka.shizuku.**
